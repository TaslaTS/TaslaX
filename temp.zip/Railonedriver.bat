@echo off
echo ==========================================
echo Installing Chromium for Playwright (.NET)
echo ==========================================

:: Go to the directory of the BAT file
cd /d "%~dp0"

:: Check if playwright.ps1 exists
if not exist "%~dp0playwright.ps1" (
    echo ERROR: playwright.ps1 not found in this folder!
    echo Make sure this BAT file is in the folder with your Playwright DLLs.
    pause
    exit /b 1
)

echo Running Playwright installer...

:: Run the built-in playwright.ps1 installer
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0playwright.ps1" install chromium

echo.
echo ==========================================
echo Chromium installation completed!
echo ==========================================
pause
